<?php

/**
 * Testimonial Carousel Shortcode
 *
 * @version 1.0
 * @package Lezada
 */
class WPBakeryShortCode_Lezada_Testimonial_Carousel extends WPBakeryShortCode {

}

// Mapping shortcode.
vc_map( array(
	'name'        => esc_html__( 'Testimonials Carousel', 'lezada-addons' ),
	'base'        => 'lezada_testimonial_carousel',
	'icon'        => 'lezada-element-icon-testimonials',
	'category'    => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'description' => esc_html__( 'Show testimonials in a carousel', 'lezada-addons' ),
	'params'      => array(

		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'Style', 'lezada-addons' ),
			'param_name'  => 'style_testimonial',
			'description' => esc_html__( 'Choose the style of testimonial ', 'lezada-addons' ),
			'value'       => array(
				__( 'Single testimonial', 'lezada-addons' )   => 'single',
				__( 'Multiple testimonials', 'lezada-addons' ) => 'multiple',
			),

		),

		array(
			'type'        => 'number',
			'heading'     => esc_html__( 'Number of items', 'lezada-addons' ),
			'param_name'  => 'item_count',
			'description' => esc_html__( 'The number of testimonials to show. Enter -1 to show ALL testimonials (limited to 1000)',
				'lezada-addons' ),
			'value'       => - 1,
			'max'         => 1000,
			'min'         => - 1,
			'step'        => 1,
		),
		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'Number of items to show', 'lezada-addons' ),
			'param_name'  => 'items_to_show',
			'description' => esc_html__( 'The number items testimonials to show on page.',
				'lezada-addons' ),
			'value'       => array(
				__( '1 testimonial', 'lezada-addons' )  => 1,
				__( '2 testimonials', 'lezada-addons' ) => 2,
				__( '3 testimonials', 'lezada-addons' ) => 3,
				__( '4 testimonials', 'lezada-addons' ) => 4,
			),
			'dependency'  => array(
				'element' => 'style_testimonial',
				'value'   => 'multiple',
			),

		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Testimonials Order', 'lezada-addons' ),
			'param_name'  => 'order',
			'value'       => array(
				__( 'Random', 'lezada-addons' ) => 'rand',
				__( 'Latest', 'lezada-addons' ) => 'date',
			),
			'description' => __( 'Choose the order of the testimonials.', 'lezada-addons' ),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => __( 'Testimonials category', 'lezada-addons' ),
			'param_name'  => 'category',
			'value'       => Lezada_VC::get_category_list( 'testimonial-category' ),
			'description' => __( 'Choose the category for the testimonials.', 'lezada-addons' ),
		),

		array(
			'type'       => 'checkbox',
			'param_name' => 'loop',
			'value'      => array( esc_html__( 'Enable carousel loop mode', 'lezada-addons' ) => 'yes' ),
			'std'        => 'yes',
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'auto_play',
			'value'      => array( esc_html__( 'Enable carousel autolay', 'lezada-addons' ) => 'yes' ),
		),
		array(
			'type'       => 'number',
			'param_name' => 'auto_play_speed',
			'heading'    => esc_html__( 'Auto play speed', 'lezada-addons' ),
			'value'      => 5,
			'max'        => 10,
			'min'        => 3,
			'step'       => 0.5,
			'suffix'     => 'seconds',
			'dependency' => array(
				'element' => 'auto_play',
				'value'   => 'yes',
			),
		),
		array(
			'type'       => 'dropdown',
			'param_name' => 'nav_type',
			'heading'    => esc_html__( 'Navigation type', 'lezada-addons' ),
			'value'      => array(
				esc_html__( 'Arrows', 'lezada-addons' ) => 'arrows',
				esc_html__( 'Dots', 'lezada-addons' )   => 'dots',
				__( 'Arrows & Dots', 'lezada-addons' )  => 'both',
				esc_html__( 'None', 'lezada-addons' )   => '',
			),
		),

		Lezada_VC::get_param( 'el_class' ),
		Lezada_VC::get_param( 'css' ),
		Lezada_VC::get_animation_field(),
	),
) );

