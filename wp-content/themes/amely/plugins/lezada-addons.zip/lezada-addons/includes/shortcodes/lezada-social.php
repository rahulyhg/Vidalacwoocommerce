<?php

/**
 * Social Links Shortcode
 *
 * @version 1.0
 * @package lezada
 */
class WPBakeryShortCode_lezada_Social extends WPBakeryShortCode {

	public function getSocialLinks( $atts ) {
		$social_links     = preg_split( '/\s+/', $atts['social_links'] );
		$social_links_arr = array();

		foreach ( $social_links as $social ) {
			$pieces = explode( '|', $social );
			if ( count( $pieces ) == 2 ) {
				$key                      = $pieces[0];
				$link                     = ( $key == 'envelope-o' ) ? 'mailto:' . $pieces[1] : $pieces[1];
				$social_links_arr[ $key ] = $link;
			}
		}

		return $social_links_arr;
	}

	public function shortcode_css( $css_id ) {

		$atts   = vc_map_get_attributes( $this->getShortcode(), $this->getAtts() );
		$css    = '';
		$css_id = '#' . $css_id;

		if ( is_rtl() ) {
			$css .= $css_id . ' .social-links li{margin-left:' . intval( $atts['spacing'] ) . 'px;}';
		} else {
			$css .= $css_id . ' .social-links li{margin-right:' . intval( $atts['spacing'] ) . 'px;}';
		}

		$css .= $css_id . ' li,' . $css_id . ' i' . '{font-size:' . $atts['icon_font_size'] . 'px}';
		$css .= $css_id . ' i{color:' . $atts['icon_color'];
		$css .= ';background-color:' . $atts['icon_bgcolor'];
		$css .= '}';

		$css .= $css_id . ' li:hover i{color:' . $atts['icon_color_hover'];
		$css .= ';background-color:' . $atts['icon_bgcolor_hover'];
		$css .= '}';

		$css = Lezada_Helper::text2line( $css );

		global $lezada_shortcode_css;
		$lezada_shortcode_css .= $css;
	}
}

vc_map( array(
	'name'     => esc_html__( 'Social Links', 'lezada-addons' ),
	'base'     => 'lezada_social',
	'icon'     => 'lezada-element-icon-social-links',
	'category' => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'params'   => array(
		array(
			'type'       => 'number',
			'param_name' => 'icon_font_size',
			'heading'    => esc_html__( 'Icon font size', 'lezada-addons' ),
			'value'      => 24,
			'min'        => 10,
			'max'        => 50,
			'step'       => 1,
			'suffix'     => 'px',
		),
		array(
			'type'       => 'number',
			'param_name' => 'spacing',
			'heading'    => esc_html__( 'Spacing', 'lezada-addons' ),
			'value'      => 10,
			'min'        => 0,
			'max'        => 50,
			'step'       => 1,
			'suffix'     => 'px',
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'display_name_social',
			'value'      => array( esc_html__( 'Display name social', 'lezada-addons' ) => 'no ' ),
		),
		array(
			'type'       => 'dropdown',
			'param_name' => 'social_align',
			'heading'    => esc_html__( 'Social Align', 'lezada-addons' ),
			'value'      => array(
				esc_html__( 'Left', 'lezada-addons' )   => 'left',
				esc_html__( 'Center', 'lezada-addons' ) => 'center',
				esc_html__( 'Right', 'lezada-addons' )  => 'right',
			),
			'std'        => 'left',
		),
		array(
			'type'        => 'dropdown',
			'param_name'  => 'icon_shape',
			'heading'     => esc_html__( 'Icon background shape', 'lezada-addons' ),
			'value'       => array(
				esc_html__( 'None', 'lezada-addons' )   => 'none',
				esc_html__( 'Circle', 'lezada-addons' ) => 'circle',
				esc_html__( 'Square', 'lezada-addons' ) => 'square',
			),
			'std'         => 'circle',
			'description' => esc_html__( 'Select background shape and style for icons', 'lezada-addons' ),
		),
		array(
			'group'      => esc_html__( 'Social', 'lezada-addons' ),
			'type'       => 'dropdown',
			'param_name' => 'source',
			'heading'    => esc_html__( 'Select Social Link', 'lezada-addons' ),
			'value'      => array(
				esc_html__( 'Default (From Theme Options)', 'lezada-addons' ) => 'default',
				esc_html__( 'Custom', 'lezada-addons' )                       => 'custom',
			),
			'std'        => 'default',
		),
		array(
			'group'      => esc_html__( 'Social', 'lezada-addons' ),
			'type'       => 'social_links',
			'heading'    => esc_html__( 'Social links', 'lezada-addons' ),
			'param_name' => 'social_links',
			'dependency' => array(
				'element' => 'source',
				'value'   => 'custom',
			),
		),
		array(
			'group'      => esc_html__( 'Color', 'lezada-addons' ),
			'type'       => 'colorpicker',
			'param_name' => 'icon_color',
			'heading'    => esc_html__( 'Icon color', 'lezada-addons' ),
			'value'      => '##999999',
		),
		array(
			'group'      => esc_html__( 'Color', 'lezada-addons' ),
			'type'       => 'colorpicker',
			'param_name' => 'icon_color_hover',
			'heading'    => esc_html__( 'Icon color on hover', 'lezada-addons' ),
			'value'      => '#333333',
		),
		array(
			'group'      => esc_html__( 'Color', 'lezada-addons' ),
			'type'       => 'colorpicker',
			'param_name' => 'icon_bgcolor',
			'heading'    => esc_html__( 'Icon background color', 'lezada-addons' ),
			'value'      => '#ffffff',
			'dependency' => array(
				'element'            => 'icon_shape',
				'value_not_equal_to' => 'none',
			),
		),
		array(
			'group'      => esc_html__( 'Color', 'lezada-addons' ),
			'type'       => 'colorpicker',
			'param_name' => 'icon_bgcolor_hover',
			'heading'    => esc_html__( 'Icon background color on hover', 'lezada-addons' ),
			'value'      => '#ffffff',
			'dependency' => array(
				'element'            => 'icon_shape',
				'value_not_equal_to' => 'none',
			),
		),
		Lezada_VC::get_param( 'el_class' ),
		Lezada_VC::get_param( 'css' ),
	),
) );
