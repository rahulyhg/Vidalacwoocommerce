<?php

/**
 * ThemeMove Banner Carousel Shortcode
 *
 * @version 1.0
 * @package lezada
 */
class WPBakeryShortCode_Lezada_Banner_Carousel extends WPBakeryShortCode {
}

vc_map( array(
	'name'        => esc_html__( 'Banner Carousel', 'lezada-addons' ),
	'description' => esc_html__( 'Display banner center image carousel', 'lezada-addons' ),
	'base'        => 'lezada_banner_carousel',
	'icon'        => 'lezada-element-icon-banner-carousel',
	'category'    => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'params'      => array(

		array(
			'type'       => 'param_group',
			'heading'    => esc_html__( 'Single Banner', 'lezada-addons' ),
			'param_name' => 'single_banner',
			'params'     => array(
				array(
					'type'        => 'attach_image',
					'heading'     => esc_html__( 'Image Product', 'lezada-addons' ),
					'param_name'  => 'image',
					'value'       => '',
					'description' => esc_html__( 'Select an image from media library.', 'lezada-addons' ),
				),
				array(
					'heading'     => esc_html__( 'Title Banner', 'lezada-addons' ),
					'description' => esc_html__( 'A short text display before the banner text', 'lezada-addons' ),
					'type'        => 'textfield',
					'param_name'  => 'title',
				),
				array(
					'heading'    => esc_html__( 'Title Color', 'lezada-addons' ),
					'type'       => 'colorpicker',
					'param_name' => 'title_color',
					'value'      => '#333',
				),
				array(
					'heading'     => esc_html__( 'Banner Text', 'lezada-addons' ),
					'description' => esc_html__( 'Enter the banner text', 'lezada-addons' ),
					'type'        => 'textarea',
					'param_name'  => 'content',
				),
				array(
					'heading'    => esc_html__( 'Banner Text Color', 'lezada-addons' ),
					'type'       => 'colorpicker',
					'param_name' => 'content_color',
					'value'      => '#333',
				),
				array(
					'heading'    => esc_html__( 'Banner Link', 'lezada-addons' ),
					'type'       => 'vc_link',
					'param_name' => 'link',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Text Align and position', 'lezada-addons' ),
					'description' => esc_html__( 'Select the text align and position for content.', 'lezada-addons' ),
					'param_name'  => 'text_align_position',
					'value'       => array(
						esc_html__( 'Left', 'lezada-addons' )   => 'left',
						esc_html__( 'Center', 'lezada-addons' ) => 'center',
						esc_html__( 'Right', 'lezada-addons' )  => 'right',
					),
					'std'         => 'left',
				),
			),
		),

		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'CSS Animation', 'lezada-addons' ),
			'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).',
				'lezada-addons' ),
			'param_name'  => 'animation',
			'value'       => array(
				esc_html__( 'None', 'lezada-addons' )             => '',
				esc_html__( 'Fade In', 'lezada-addons' )          => 'fade-in',
				esc_html__( 'Move Up', 'lezada-addons' )          => 'move-up',
				esc_html__( 'Move Down', 'lezada-addons' )        => 'move-down',
				esc_html__( 'Move Left', 'lezada-addons' )        => 'move-left',
				esc_html__( 'Move Right', 'lezada-addons' )       => 'move-right',
				esc_html__( 'Scale Up', 'lezada-addons' )         => 'scale-up',
				esc_html__( 'Fall Perspective', 'lezada-addons' ) => 'fall-perspective',
				esc_html__( 'Fly', 'lezada-addons' )              => 'fly',
				esc_html__( 'Flip', 'lezada-addons' )             => 'flip',
				esc_html__( 'Helix', 'lezada-addons' )            => 'helix',
				esc_html__( 'Pop Up', 'lezada-addons' )           => 'pop-up',
			),
			'std'         => 'scale-up',
		),
		Lezada_VC::get_param( 'el_class' ),
		Lezada_VC::get_param( 'css' ),
	),
) );
