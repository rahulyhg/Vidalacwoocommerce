<?php

/**
 * ThemeMove Team Member Shortcode
 *
 * @version 1.0
 * @package Lezada
 */
class WPBakeryShortCode_Lezada_Team_Member extends WPBakeryShortCode {

	public function getSocialLinks( $atts ) {
		$social_links     = preg_split( '/\s+/', $atts['social_links'] );
		$social_links_arr = array();

		foreach ( $social_links as $social ) {
			$pieces = explode( '|', $social );
			if ( count( $pieces ) == 2 ) {
				$key                      = $pieces[0];
				$link                     = $pieces[1];
				$social_links_arr[ $key ] = $link;
			}
		}

		return $social_links_arr;
	}

}

// Mapping shortcode.
vc_map( array(
	'name'     => esc_html__( 'Team Member', 'lezada-addons' ),
	'base'     => 'lezada_team_member',
	'icon'     => 'lezada-element-icon-team-member',
	'category' => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'params'   => array(
		array(
			'type'        => 'attach_image',
			'heading'     => esc_html__( 'Image', 'lezada-addons' ),
			'param_name'  => 'image',
			'value'       => '',
			'description' => esc_html__( 'Select an image from media library.', 'lezada-addons' ),
		),
		array(
			'type'        => 'textfield',
			'heading'     => esc_html__( 'Name', 'lezada-addons' ),
			'param_name'  => 'name',
			'admin_label' => true,
		),
		array(
			'type'        => 'textfield',
			'heading'     => esc_html__( 'Role', 'lezada-addons' ),
			'param_name'  => 'role',
			'description' => esc_html__( 'Add a role. E.g. CEO of ThemeMove', 'lezada-addons' ),
			'admin_label' => true,
		),
		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'Style', 'lezada-addons' ),
			'param_name'  => 'style',
			'admin_label' => true,
			'std'         => 'circle',
			'value'       => array(
				esc_html__( 'Circle', 'lezada-addons' )  => 'circle',
				esc_html__( 'Square', 'lezada-addons' )  => 'square',
			),
		),
		Lezada_VC::get_param( 'el_class' ),
		array(
			'group'      => esc_html__( 'Social', 'lezada-addons' ),
			'type'       => 'checkbox',
			'param_name' => 'link_new_page',
			'value'      => array( esc_html__( 'Open links in new tab', 'lezada-addons' ) => 'yes' ),
		),
		array(
			'group'      => esc_html__( 'Social', 'lezada-addons' ),
			'type'       => 'social_links',
			'heading'    => esc_html__( 'Social links', 'lezada-addons' ),
			'param_name' => 'social_links',
		),
		Lezada_VC::get_param( 'css' ),
		Lezada_VC::get_animation_field(),
	),
) );
