<?php

/**
 * Lezada Instagram shortcode
 *
 * @version 1.0
 * @package Lezada
 */
class WPBakeryShortCode_Lezada_Instagram extends WPBakeryShortCode {

	public function get_grid_item_class( $number_of_cols ) {

		$total_cols = 12;
		$classes    = array();

		if ( ! is_array( $number_of_cols ) && is_numeric( $number_of_cols ) && $number_of_cols > 0 ) {

			if ( 0 == $total_cols % $cols ) {
				$width     = $total_cols / $cols;
				$classes[] = 'col-md-' . $width;
			} else {
				if ( 5 == $cols ) {
					$classes[] = 'col-md-is-5';
				}
			}
		} else {

			foreach ( $number_of_cols as $media_query => $cols ) {

				$cols = intval( $cols );

				if ( $cols == 0 ) {
					$cols = 1;
				}

				if ( 0 == $total_cols % $cols ) {
					$width     = $total_cols / $cols;
					$classes[] = 'col-' . $media_query . '-' . $width;
				} else {
					if ( 5 == $cols ) {
						$classes[] = 'col-' . $media_query . '-is-5';
					}
				}
			}
		}

		return join( ' ', $classes );
	}
}

// Mapping shortcode
vc_map( array(
	'name'        => esc_html__( 'Instagram', 'lezada-addons' ),
	'base'        => 'lezada_instagram',
	'icon'        => 'lezada-element-icon-instagram',
	'category'    => sprintf( esc_html__( 'by % s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'description' => esc_html__( 'Displays latest Instagram photos', 'lezada-addons' ),
	'params'      => array(
		array(
			'type'        => 'textfield',
			'heading'     => __( 'Instagram Username', 'lezada-addons' ),
			'admin_label' => true,
			'param_name'  => 'username',
			'value'       => '',
			'description' => wp_kses( __( 'Enter Instagram username (not include @). Example: <b>thememove</b>',
				'lezada-addons' ),
				array( 'b' => array() ) ),
		),

		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'View mode', 'lezada-addons' ),
			'description' => esc_html__( 'Select a template to display instagram', 'lezada-addons' ),
			'param_name'  => 'view',
			'admin_label' => true,
			'value'       => array(
				esc_html__( 'Grid', 'lezada-addons' )     => 'grid',
				esc_html__( 'Carousel', 'lezada-addons' ) => 'carousel',
			),
		),

		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'Image Align', 'lezada-addons' ),
			'description' => esc_html__( 'Select an image align to display instagram', 'lezada-addons' ),
			'param_name'  => 'image_align',
			'admin_label' => true,
			'value'       => array(
				esc_html__( 'Center', 'lezada-addons' ) => 'center',
				esc_html__( 'Left', 'lezada-addons' )   => 'left',
				esc_html__( 'Right', 'lezada-addons' )  => 'right',
			),
		),

		array(
			'type'        => 'number',
			'heading'     => esc_html__( 'Number of items', 'lezada-addons' ),
			'param_name'  => 'number_items',
			'value'       => 1,
			'max'         => 1000,
			'min'         => 1,
			'step'        => 1,
			'description' => esc_html__( 'Set number of items in grid (limited to 1000)',
				'lezada-addons' ),
		),

		array(
			'type'       => 'checkbox',
			'param_name' => 'loop',
			'value'      => array( esc_html__( 'Enable loop mode', 'lezada-addons' ) => 'yes' ),
			'std'        => 'yes',
			'dependency' => array( 'element' => 'view', 'value' => array( 'carousel' ) ),
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'auto_play',
			'value'      => array( esc_html__( 'Enable carousel autoplay', 'lezada-addons' ) => 'yes' ),
			'dependency' => array(
				'element' => 'view',
				'value'   => array( 'carousel' ),
			),
		),

		array(
			'type'       => 'number',
			'param_name' => 'auto_play_speed',
			'heading'    => esc_html__( 'Auto play speed', 'lezada-addons' ),
			'value'      => 5,
			'max'        => 10,
			'min'        => 3,
			'step'       => 0.5,
			'suffix'     => 'seconds',
			'dependency' => array(
				'element' => 'auto_play',
				'value'   => 'yes',
			),
		),

		array(
			'type'       => 'dropdown',
			'param_name' => 'nav_type',
			'heading'    => esc_html__( 'Navigation type', 'lezada-addons' ),
			'value'      => array(
				esc_html__( 'Arrows', 'lezada-addons' ) => 'arrows',
				esc_html__( 'Dots', 'lezada-addons' )   => 'dots',
				__( 'Arrows & Dots', 'lezada-addons' )  => 'both',
				esc_html__( 'None', 'lezada-addons' )   => '',
			),
			'dependency' => array(
				'element' => 'view',
				'value'   => array( 'carousel' ),
			),
		),

		array(
			'type'       => 'dropdown',
			'heading'    => esc_html__( 'Number of images to show', 'lezada-addons' ),
			'param_name' => 'number_of_items_to_show',
			'value'      => array(
				1,
				2,
				3,
				4,
				5,
				6,
			),
			'std'        => 4,
		),

		array(
			'type'       => 'number',
			'heading'    => esc_html__( 'Gap', 'lezada-addons' ),
			'param_name' => 'gap',
			'value'      => 15,
			'max'        => 50,
			'min'        => 5,
			'step'       => 1,
			'suffix'     => 'px',
		),

		array(
			'type'       => 'checkbox',
			'param_name' => 'show_username',
			'value'      => array(
				esc_html__( 'Show Instagram username', 'lezada-addons' ) => 'yes',
			),
		),

		array(
			'type'       => 'checkbox',
			'param_name' => 'show_likes_comments',
			'value'      => array(
				esc_html__( 'Show likes and comments', 'lezada-addons' ) => 'yes',
			),
			'std'        => 'yes',
		),
		array(
			'type'        => 'textarea_html',
			'heading'     => __( 'Text', 'lezada-addons' ),
			'param_name'  => 'content',
			'value'       => __( 'Follow us on Instagram', 'lezada-addons' ),
			'description' => esc_html__( 'Leave empty to hide it', 'lezada-addons' ),
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'link_new_page',
			'value'      => array(
				esc_html__( 'Open links in new page', 'lezada-addons' ) => 'yes',
			),
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'square_media',
			'value'      => array(
				esc_html__( 'Show square media', 'lezada-addons' ) => 'yes',
			),
			'std'        => 'yes',
		),
		Lezada_VC::get_param( 'el_class' ),
		Lezada_VC::get_param( 'css' ),
		Lezada_VC::get_animation_field(),
	),

) );
