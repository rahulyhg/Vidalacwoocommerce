<?php

/**
 * Lezada Product Grid Shortcode
 *
 * @version 1.0
 * @package Lezada
 */
class WPBakeryShortCode_Lezada_Product_Grid extends WPBakeryShortCode {

	public function __construct( $settings ) {
		parent::__construct( $settings );
		add_filter( 'lezada_shop_products_columns', array( $this, 'product_columns' ) );
		add_filter( 'lezada_product_loop_thumbnail_size', array( $this, 'image_size' ) );
	}

	public function product_columns() {

		$atts = $this->getAtts();

		return array(
			'xs' => 1,
			'sm' => 2,
			'md' => 3,
			'lg' => 4,
			'xl' => $atts['columns'],
		);
	}

	public function image_size() {

		$atts = $this->getAtts();

		if ( empty( $atts['img_size'] ) ) {
			$atts['img_size'] = 'woocommerce_thumbnail';
		}

		return isset( $atts['img_size'] ) ? Lezada_VC::convert_image_size( $atts['img_size'] ) : 'woocommerce_thumbnail';
	}
}

// Mapping shortcode.
vc_map( array(
	'name'        => esc_html__( 'Product Grid', 'lezada-addons' ),
	'base'        => 'lezada_product_grid',
	'icon'        => 'lezada-element-icon-product-grid',
	'category'    => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'description' => esc_html__( 'Add products in a grid', 'lezada-addons' ),
	'params'      => array(
		array(
			'type'        => 'dropdown',
			'param_name'  => 'data_source',
			'admin_label' => true,
			'heading'     => esc_html__( 'Data source', 'lezada-addons' ),
			'value'       => array(
				esc_html__( 'Recent Products', 'lezada-addons' )       => 'recent_products',
				esc_html__( 'Featured Products', 'lezada-addons' )     => 'featured_products',
				esc_html__( 'On Sale Products', 'lezada-addons' )      => 'sale_products',
				esc_html__( 'Best-Selling Products', 'lezada-addons' ) => 'best_selling_products',
				esc_html__( 'Related Products', 'lezada-addons' )      => 'related_products',
				esc_html__( 'Top Rated Products', 'lezada-addons' )    => 'top_rated_products',
				esc_html__( 'Product Attribute', 'lezada-addons' )     => 'product_attribute',
				esc_html__( 'List of Products', 'lezada-addons' )      => 'products',
				esc_html__( 'Categories', 'lezada-addons' )            => 'categories',
			),
			'description' => esc_html__( 'Select data source for your product grid', 'lezada-addons' ),
		),

		Lezada_VC::get_param( 'product_cat_autocomplete',
			'',
			array(
				'element' => 'data_source',
				'value'   => array( 'categories' ),
			) ),

		Lezada_VC::get_param( 'product_autocomplete',
			'',
			array(
				'element' => 'data_source',
				'value'   => array( 'products' ),
			) ),

		Lezada_VC::get_param( 'product_attribute',
			'',
			array(
				'element' => 'data_source',
				'value'   => array( 'product_attribute' ),
			) ),

		Lezada_VC::get_param( 'product_term',
			'',
			array(
				'element' => 'data_source',
				'value'   => array( 'product_attribute' ),
			) ),

		array(
			'type'        => 'number',
			'param_name'  => 'number',
			'heading'     => esc_html__( 'Number', 'lezada-addons' ),
			'description' => esc_html__( 'Number of products in the grid (-1 is all, limited to 1000)', 'lezada-addons' ),
			'value'       => 12,
			'max'         => 1000,
			'min'         => - 1,
			'dependency'  => array( 'element' => 'data_source', 'value_not_equal_to' => array( 'products' ) ),
		),

		Lezada_VC::get_param( 'columns' ),

		array(
			'type'       => 'autocomplete',
			'heading'    => esc_html__( 'Exclude products', 'lezada-addons' ),
			'param_name' => 'exclude',
			'settings'   => array(
				'multiple' => true,
				'sortable' => true,
			),
		),

		array(
			'type'        => 'checkbox',
			'param_name'  => 'include_children',
			'description' => esc_html__( 'Whether or not to include children categories', 'lezada-addons' ),
			'value'       => array( esc_html__( 'Include children', 'lezada-addons' ) => 'yes' ),
			'std'         => 'yes',
			'dependency'  => array( 'element' => 'data_source', 'value' => array( 'categories' ) ),
		),

		array(
			'type'        => 'textfield',
			'heading'     => esc_html__( 'Image size', 'lezada-addons' ),
			'param_name'  => 'img_size',
			'value'       => 'woocommerce_thumbnail',
			'description' => esc_html__( 'Enter image size . Example: "thumbnail", "medium", "large", "full" or other sizes defined by current theme . Alternatively enter image size in pixels: 200x100( Width x Height). Leave empty to use "woocommerce_thumbnail" size . ',
				'lezada-addons' ),
		),

		array(
			'type'       => 'dropdown',
			'param_name' => 'pagination_type',
			'heading'    => esc_html__( 'Pagination type', 'lezada-addons' ),
			'value'      => array(
				esc_html__( 'None', 'lezada-addons' )             => '',
				esc_html__( 'Load More Button', 'lezada-addons' ) => 'more-btn',
				esc_html__( 'Infinite Scroll', 'lezada-addons' )  => 'infinite',
			),
			'dependency' => array(
				'element'            => 'data_source',
				'value_not_equal_to' => array( 'products' ),
			),
		),

		array(
			'type'       => 'dropdown',
			'param_name' => 'product_style',
			'heading'    => esc_html__( 'Select product item style', 'lezada-addons' ),
			'value'      => array(
				esc_html__( 'Default', 'lezada-addons' )          => 'default',
				esc_html__( 'Button Hover', 'lezada-addons' )     => 'button-hover',
				esc_html__( 'Button Hover Alt', 'lezada-addons' ) => 'button-hover-alt',
			),
		),

		Lezada_VC::get_param( 'el_class' ),
		// Data settings.
		Lezada_VC::get_param( 'order_product',
			esc_html__( 'Data Settings', 'lezada-addons' ),
			array(
				'element'            => 'data_source',
				'value_not_equal_to' => array(
					'recent_products',
					'best_selling_products',
					'top_rated_products',
				),
			) ),
		Lezada_VC::get_param( 'order_way',
			esc_html__( 'Data Settings', 'lezada-addons' ),
			array(
				'element'            => 'data_source',
				'value_not_equal_to' => array(
					'recent_products',
					'best_selling_products',
					'top_rated_products',
				),
			) ),
		Lezada_VC::get_param( 'css' ),
		Lezada_VC::get_animation_field(),
	),
) );


//Filters For autocomplete param:
//For suggestion: vc_autocomplete_[shortcode_name]_[param_name]_callback
add_filter( 'vc_autocomplete_lezada_product_grid_product_ids_callback',
	array(
		'Lezada_VC',
		'product_id_callback',
	),
	10,
	1 );

add_filter( 'vc_autocomplete_lezada_product_grid_product_ids_render',
	array(
		'Lezada_VC',
		'product_id_render',
	),
	10,
	1 );

add_filter( 'vc_autocomplete_lezada_product_grid_exclude_callback',
	array(
		'Lezada_VC',
		'product_id_callback',
	),
	10,
	1 );

add_filter( 'vc_autocomplete_lezada_product_grid_exclude_render',
	array(
		'Lezada_VC',
		'product_id_render',
	),
	10,
	1 );

//For param: "filter" param value
//vc_form_fields_render_field_{shortcode_name}_{param_name}_param
add_filter( 'vc_form_fields_render_field_lezada_product_grid_filter_param',
	array(
		'Lezada_VC',
		'product_attribute_filter_param_value',
	),
	10,
	4 ); // Defines default value for param if not provided. Takes from other param value.
