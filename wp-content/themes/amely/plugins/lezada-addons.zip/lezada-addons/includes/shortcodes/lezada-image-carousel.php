<?php

/**
 * lezada Image Carousel
 *
 * @version 1.0
 * @package Lezada
 */
class WPBakeryShortCode_Lezada_Image_Carousel extends WPBakeryShortCode {

	public function shortcode_css( $css_id ) {

		$atts   = vc_map_get_attributes( $this->getShortcode(), $this->getAtts() );
		$css_id = '#' . $css_id;
		$css    = '';

		$effect  = $atts['effect'];
		$opacity = $atts['opacity'];
		$scale   = $atts['scale'];
		$overlay = $atts['overlay'];

		switch ( $effect ) {
			case 'opacity':
				$css .= $css_id . ' .tm-carousel-item img{opacity:' . $opacity . '}';
				$css .= $css_id . ' .tm-carousel-item:hover img{opacity:1}';
				break;
			case 'zoom':
				$css .= $css_id . ' .tm-carousel-item img{ -ms-transform: scale(1);-webkit-transform: scale(1);transform: scale(1);}';
				$css .= $css_id . ' .tm-carousel-item:hover img{ -ms-transform: scale(' . $scale . ');-webkit-transform: scale(' . $scale . ');transform: scale(' . $scale . ');}';
				break;
			case 'overlay':
				$css .= $css_id . '.link-no .tm-carousel-item:before,' . $css_id . ' .tm-carousel-item a:before{background-color:' . $overlay . '}';
				break;
			default:
				break;
		}

		global $lezada_shortcode_css;
		$lezada_shortcode_css .= $css;
	}
}

vc_map( array(
	'name'        => esc_html__( 'Image Carousel', 'lezada-addons' ),
	'base'        => 'lezada_image_carousel',
	'icon'        => 'lezada-element-icon-image-carousel',
	'description' => esc_html__( 'Animated carousel with images', 'lezada-addons' ),
	'category'    => sprintf( esc_html__( 'by % s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'params'      => array(
		array(
			'type'        => 'attach_images',
			'heading'     => esc_html__( 'Images', 'lezada-addons' ),
			'param_name'  => 'images',
			'value'       => '',
			'description' => esc_html__( 'Select images from media library . ', 'lezada-addons' ),
			'save_always' => true,
		),
		array(
			'type'        => 'textfield',
			'heading'     => esc_html__( 'Carousel image size', 'lezada-addons' ),
			'param_name'  => 'img_size',
			'value'       => 'full',
			'description' => esc_html__( 'Enter image size . Example: "thumbnail", "medium", "large", "full" or other sizes defined by current theme . Alternatively enter image size in pixels: 200x100( Width x Height). Leave empty to use "thumbnail" size . ', 'lezada-addons' ),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'On click action', 'lezada-addons' ),
			'param_name'  => 'onclick',
			'value'       => array(
				esc_html__( 'None', 'lezada-addons' )              => 'link_no',
				esc_html__( 'Open lightbox', 'lezada-addons' )     => 'link_image',
				esc_html__( 'Open custom links', 'lezada-addons' ) => 'custom_link',
			),
			'description' => esc_html__( 'Select action for click event. ', 'lezada-addons' ),
		),
		array(
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'Custom link target', 'lezada-addons' ),
			'param_name'  => 'custom_links_target',
			'description' => esc_html__( 'Select how to open custom links . ', 'lezada-addons' ),
			'dependency'  => array(
				'element' => 'onclick',
				'value'   => array( 'custom_link' ),
			),
			'value'       => vc_target_param_list(),
		),

		array(
			'type'        => 'exploded_textarea_safe',
			'heading'     => esc_html__( 'Custom links', 'lezada-addons' ),
			'param_name'  => 'custom_links',
			'description' => esc_html__( 'Enter links for each slide( Note: divide links with linebreaks( Enter ).', 'lezada-addons' ),
			'dependency'  => array(
				'element' => 'onclick',
				'value'   => array( 'custom_link' ),
			),
		),
		array(
			'type'       => 'dropdown',
			'heading'    => esc_html__( 'Number of images to show', 'lezada-addons' ),
			'param_name' => 'number_of_images_to_show',
			'value'      => array(
				1,
				2,
				3,
				4,
				5,
				6,
			),
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'loop',
			'value'      => array( esc_html__( 'Enable carousel loop mode', 'lezada-addons' ) => 'yes' ),
			'std'        => 'yes',
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'auto_play',
			'value'      => array( esc_html__( 'Enable carousel autolay', 'lezada-addons' ) => 'yes' ),
		),
		array(
			'type'       => 'number',
			'param_name' => 'auto_play_speed',
			'heading'    => esc_html__( 'Auto play speed', 'lezada-addons' ),
			'value'      => 5,
			'max'        => 10,
			'min'        => 3,
			'step'       => 0.5,
			'suffix'     => 'seconds',
			'dependency' => array(
				'element' => 'auto_play',
				'value'   => 'yes',
			),
		),
		array(
			'type'       => 'dropdown',
			'param_name' => 'nav_type',
			'heading'    => esc_html__( 'Navigation type', 'lezada-addons' ),
			'value'      => array(
				esc_html__( 'Arrows', 'lezada-addons' ) => 'arrows',
				esc_html__( 'Dots', 'lezada-addons' )   => 'dots',
				__( 'Arrows & Dots', 'lezada-addons' )  => 'both',
				esc_html__( 'None', 'lezada-addons' )   => '',
			),
		),
		array(
			'type'       => 'checkbox',
			'param_name' => 'show_title',
			'value'      => array( esc_html__( 'Show title of images', 'lezada-addons' ) => 'yes' ),
		),
		Lezada_VC::get_param( 'el_class' ),
		array(
			'group'       => esc_html__( 'Hover effect', 'lezada-addons' ),
			'type'        => 'dropdown',
			'param_name'  => 'effect',
			'heading'     => esc_html__( 'Image hover effect', 'lezada-addons' ),
			'description' => esc_html__( 'Select an effect when mouse over the images . ', 'lezada-addons' ),
			'value'       => array(
				esc_html__( 'Opacity', 'lezada-addons' ) => 'opacity',
				esc_html__( 'Zoom', 'lezada-addons' )    => 'zoom',
				esc_html__( 'Overlay', 'lezada-addons' ) => 'overlay',
			),
		),
		array(
			'group'      => esc_html__( 'Hover effect', 'lezada-addons' ),
			'type'       => 'number',
			'heading'    => esc_html__( 'Opacity value from', 'lezada-addons' ),
			'param_name' => 'opacity',
			'value'      => 0.6,
			'min'        => 0,
			'max'        => 1,
			'step'       => 0.1,
			'suffix'     => 'to 1',
			'dependency' => array(
				'element' => 'effect',
				'value'   => array( 'opacity' ),
			),
		),
		array(
			'group'      => esc_html__( 'Hover effect', 'lezada-addons' ),
			'type'       => 'number',
			'heading'    => esc_html__( 'Zoom scale', 'lezada-addons' ),
			'param_name' => 'scale',
			'max'        => 5,
			'min'        => 0.1,
			'value'      => 1.1,
			'step'       => 0.1,
			'dependency' => array(
				'element' => 'effect',
				'value'   => array( 'zoom' ),
			),
		),
		array(
			'group'      => esc_html__( 'Hover effect', 'lezada-addons' ),
			'type'       => 'colorpicker',
			'heading'    => esc_html__( 'Overlay color', 'lezada-addons' ),
			'param_name' => 'overlay',
			'value'      => 'rgba( 255, 255, 255, 0.6 )',
			'dependency' => array(
				'element' => 'effect',
				'value'   => array( 'overlay' ),
			),
		),
		Lezada_VC::get_param( 'css' ),
	),
) );
