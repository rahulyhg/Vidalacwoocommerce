<?php
/**
 * lezada Image Gallery
 *
 * @version 1.0
 * @package Lezada
 */
class WPBakeryShortCode_Lezada_Image_Gallery extends WPBakeryShortCode {
}

vc_map( array(
	'name'     => esc_html__( 'Lightbox Gallery', 'lezada-addons' ),
	'base'     => 'lezada_image_gallery',
	'category' => sprintf( esc_html__( 'by %s', 'lezada-addons' ), LEZADA_ADDONS_THEME_NAME ),
	'icon'     => 'lezada-element-icon-image-gallery',
	'params'   => array(

		array(
			'type'        => 'attach_images',
			'heading'     => esc_html__( 'Images', 'lezada-addons' ),
			'param_name'  => 'images',
			'value'       => '',
			'description' => esc_html__( 'Select images from media library . ', 'lezada-addons' ),
			'save_always' => true,
		),
		array(
			'type'        => 'textfield',
			'heading'     => esc_html__( 'Carousel image size', 'lezada-addons' ),
			'param_name'  => 'img_size',
			'value'       => 'full',
			'description' => esc_html__( 'Enter image size . Example: "thumbnail", "medium", "large", "full" or other sizes defined by current theme . Alternatively enter image size in pixels: 200x100( Width x Height). Leave empty to use "thumbnail" size . ', 'lezada-addons' ),
		),
		array(
			'type'       => 'dropdown',
			'heading'    => esc_html__( 'Number columns of images to show', 'lezada-addons' ),
			'param_name' => 'number_columns',
			'value'      => array(
				1,
				2,
				3,
				4,
				5,
				6,
			),
		),
		array(
			'group'       => esc_html__( 'Animation', 'lezada-addons' ),
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'Banner Hover Effect', 'lezada-addons' ),
			'admin_label' => true,
			'param_name'  => 'hover_style',
			'value'       => array(
				esc_html__( 'none', 'lezada-addons' )            => '',
				esc_html__( 'Zoom in', 'lezada-addons' )         => 'zoom-in',
				esc_html__( 'Border and zoom', 'lezada-addons' ) => 'border-zoom',
				esc_html__( 'Blur', 'lezada-addons' )            => 'blur',
				esc_html__( 'Gray scale', 'lezada-addons' )      => 'grayscale',
				esc_html__( 'White Overlay', 'lezada-addons' )   => 'white-overlay',
				esc_html__( 'Black Overlay', 'lezada-addons' )   => 'black-overlay',
			),
			'std'         => 'zoom-in',
			'description' => esc_html__( 'Select animation style for banner when mouse over. Note: Some styles only work in modern browsers',
				'lezada-addons' ),
		),
		array(
			'group'       => esc_html__( 'Animation', 'lezada-addons' ),
			'type'        => 'dropdown',
			'heading'     => esc_html__( 'CSS Animation', 'lezada-addons' ),
			'description' => esc_html__( 'Select type of animation for element to be animated when it "enters" the browsers viewport (Note: works only in modern browsers).',
				'lezada-addons' ),
			'param_name'  => 'animation',
			'value'       => array(
				esc_html__( 'None', 'lezada-addons' )             => 'none',
				esc_html__( 'Fade In', 'lezada-addons' )          => 'fade-in',
				esc_html__( 'Move Up', 'lezada-addons' )          => 'move-up',
				esc_html__( 'Move Down', 'lezada-addons' )        => 'move-down',
				esc_html__( 'Move Left', 'lezada-addons' )        => 'move-left',
				esc_html__( 'Move Right', 'lezada-addons' )       => 'move-right',
				esc_html__( 'Scale Up', 'lezada-addons' )         => 'scale-up',
				esc_html__( 'Fall Perspective', 'lezada-addons' ) => 'fall-perspective',
				esc_html__( 'Fly', 'lezada-addons' )              => 'fly',
				esc_html__( 'Flip', 'lezada-addons' )             => 'flip',
				esc_html__( 'Helix', 'lezada-addons' )            => 'helix',
				esc_html__( 'Pop Up', 'lezada-addons' )           => 'pop-up',
			),
			'std'         => 'none',
		),
		Lezada_VC::get_param( 'el_class' ),
		Lezada_VC::get_param( 'css' ),
	)
) );
