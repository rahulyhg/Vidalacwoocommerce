<?php
/**
 * Class Datetime_Picker
 *
 * @package Lezada
 */
if ( ! class_exists( 'Datetime_Picker' ) ) {
	class Datetime_Picker {

		public function __construct() {
			vc_add_shortcode_param( 'datetimepicker',
				array( $this, 'render' ),
				LEZADA_ADDONS_URL . 'includes/params/insight-datetime-picker/bootstrap-datetimepicker.min.js' );

			add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
		}

		function admin_scripts() {
			wp_enqueue_style( 'bootstrap-datetimepicker',
				LEZADA_ADDONS_URL . 'includes/params/insight-datetime-picker/bootstrap-datetimepicker.min.css' );
		}

		public function render( $settings, $value ) {
			$param_name = isset( $settings['param_name'] ) ? $settings['param_name'] : '';
			$id         = uniqid( 'datetime-picker-' );
			$output     = '<div id="' . $id . '" class="tm-datetime-picker">';
			$output     .= '<input data-format="yyyy/MM/dd hh:mm:ss" class="wpb_vc_param_value ' . $param_name . '" name="' . $param_name . '" style="width:258px;" value="' . esc_attr( $value ) . '" />';
			$output     .= '<div class="add-on" style="font-size: 18px; line-height: 1em; display: inline-block; cursor: pointer; border-radius: 0 3px 3px 0; background: #eee; border: 1px solid #ddd; padding: 8px 6px 9px; margin-left: -1px" ><i class="fa fa-calendar"></i></div>';
			$output     .= '</div>';

			return $output;
		}
	}

	new Datetime_Picker();
}


