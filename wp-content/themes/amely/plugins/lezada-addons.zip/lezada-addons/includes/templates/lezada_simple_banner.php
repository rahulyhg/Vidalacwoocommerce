<?php
/**
 * Shortcode attributes
 *
 * @var $atts
 * @var $animation
 * @var $image
 * @var $content
 * @var $style
 * @var $display_button
 * @var $link
 * @var $height
 * @var $display_border
 * @var $hover_style
 * @var $animation
 * @var $number
 * @var $el_class
 * @var $css
 * Shortcode class
 * @var $this WPBakeryShortCode_Lezada_Simple_Banner
 */

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );

$css_class = array(
	'tm-shortcode',
	'lezada-simple-banner',
	'hover-' . $hover_style,
	'style-' . $style,
	$this->getCSSAnimation( $animation ),
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

//parse link
if ( ! empty( $link ) && "||" !== $link && "|||" !== $link ) {
	$link = vc_build_link( $link );

	$a_href   = $link['url'];
	$a_title  = $link['title'];
	$a_target = $link['target'];
	$a_rel    = $link['rel'];

}

$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
	implode( ' ', $css_class ),
	$this->settings['base'],
	$atts );

if ( $animation !== '' ) {
	$css_class .= 'tm-animation ' . $animation;
}

if ( $image ) {
	$image_attr = wp_get_attachment_image_src( $image, 'full' );
}

if ( $display_border == 'yes' ) {
	$css_class .= ' has-border';
}

?>

<div class="<?php echo esc_attr( trim( $css_class ) ) ?>">
	<?php if ( $link != '' ) { ?>
		<a href="<?php echo esc_url( $a_href ); ?> "
		   title="<?php echo esc_attr( $a_title ); ?>"
		   target="<?php echo esc_attr( $a_target ? $a_target : '_self' ); ?>"
		   rel="<?php echo esc_attr( $a_rel ); ?>"></a>
	<?php } ?>
	<?php if ( $style == 'text' ) { ?>
		<?php if ( $number != '' ) { ?>
			<div class="number-status"><?php echo esc_attr( $number ); ?></div>
		<?php } ?>
		<div class="content" style="height: <?php echo '' . $height . 'px' ?>">
			<?php if ( $link && $display_button == 'yes' ) { ?>
				<div class="button-banner"><a href="<?php echo esc_url( $a_href ); ?> "
				                              title="<?php echo esc_attr( $a_title ); ?>"
				                              target="<?php echo esc_attr( $a_target ? $a_target : '_self' ); ?>"
				                              rel="<?php echo esc_attr( $a_rel ); ?>">
						<?php echo esc_attr( $a_title ); ?></a>
				</div>
			<?php } ?>
			<p class="text"><?php echo '' . $content ?></p>
		</div>

	<?php } else { ?>
		<?php if ( $style == 'image' ) { ?>
			<?php if ( $number != '' ) { ?>
				<div class="number-status"><?php echo esc_attr( $number ); ?></div>
			<?php } ?>
		<?php } ?>
		<?php if ( $link != '' && $display_button == 'yes' ) { ?>
			<div class="button-banner"><a href="<?php echo esc_url( $a_href ); ?> "
			                              title="<?php echo esc_attr( $a_title ); ?>"
			                              target="<?php echo esc_attr( $a_target ? $a_target : '_self' ); ?>"
			                              rel="<?php echo esc_attr( $a_rel ); ?>">
					<?php echo esc_attr( $a_title ); ?></a>
			</div>
		<?php } ?>
		<img src="<?php echo esc_attr( $image_attr[0] ); ?>"/>
		<div class="content"><?php echo '' . $content ?></div>
	<?php } ?>
</div>
