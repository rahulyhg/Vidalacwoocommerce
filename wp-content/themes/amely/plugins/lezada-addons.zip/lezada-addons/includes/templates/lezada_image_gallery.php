<?php
/**
 * Shortcode attributes
 *
 * @var $atts
 * @var $animation
 * @var $hover_style
 * @var $images
 * @var $img_size
 * @var $number_columns
 * @var $el_class
 * @var $css
 * Shortcode class
 * @var $this WPBakeryShortCode_Lezada_Image_Gallery
 */

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$el_class          = $this->getExtraClass( $el_class );
$animation_classes = $this->getCSSAnimation( $animation );

$css_class = array(
	'tm-shortcode',
	'lezada-image-gallery',
	' tm-animation ' . $animation . '',
	$animation_classes,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
	implode( ' ', $css_class ),
	$this->settings['base'],
	$atts );

if ( $images == '' ) {
	return;
}

$images = explode( ',', $images );

$css_id = Lezada_VC::get_shortcode_id( 'lezada-image-gallery' );

$column = '';

switch ( $number_columns ) {
	case '1':
		$column = 'col-md-12';
		break;
	case '2':
		$column = 'col-md-6';
		break;
	case '3':
		$column = 'col-md-4';
		break;
	case '4':
		$column = 'col-md-3';
		break;
	case '5':
		$column = 'col-md-is-5';
		break;
	default:
		$column = 'col-md-3';
		break;
}

?>

<div class="row <?php echo esc_attr( trim( $css_class ) ); ?>" id="<?php echo esc_attr( $css_id ); ?>">
	<?php
	if ( is_array( $images ) && ( count( $images ) > 0 ) ) {
		foreach ( $images as $image ) {
			echo '<div class="' . esc_attr( $column, 'lezada-addons' ) . '">';
			$image_full = wp_get_attachment_image_src( $image, 'full' );
			echo '<div class="image-lightbox-gallery-item' . ' hover-' . esc_attr( $hover_style, 'lezada-addons' ) . '">';
			echo '<a href="' . esc_url( $image_full[0] ) . '">' . wp_get_attachment_image( $image, 'lezada-addons' ) . '</a>';
			echo '</div>';
			echo '</div>';
		}
	}
	?>
</div>
