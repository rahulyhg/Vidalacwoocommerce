<?php
/**
 * Shortcode attributes
 *
 * @var $atts
 * @var $animation
 * @var $username
 * @var $view
 * @var $style_image
 * @var $image_align
 * @var $number_items
 * @var $loop
 * @var $auto_play
 * @var $auto_play_speed
 * @var $nav_type
 * @var $number_of_items_to_show
 * @var $show_username
 * @var $show_follow_text
 * @var $gap
 * @var $show_likes_comments
 * @var $link_new_page
 * @var $square_media
 * @var $el_class
 * @var $css
 *
 * Shortcode class
 * @var $this WPBakeryShortCode_Lezada_Instagram
 */

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$el_class = $this->getExtraClass( $el_class );

$animation_classes = $this->getCSSAnimation( $animation );

$css_class = array(
	'tm-shortcode',
	'lezada-instagram',
	'lezada-instagram--' . $view,
	$el_class,
	$animation_classes,
	' tm-animation ' . $animation . '',
	vc_shortcode_custom_css_class( $css ),
	$image_align == 'center' ?'align-center':'',
);

$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
	implode( ' ', $css_class ),
	$this->settings['base'],
	$atts );

$class = $this->get_grid_item_class( array(
	'xs' => 2,
	'sm' => 2,
	'md' => $number_of_items_to_show,
) );

if ( $number_items > 1000 ) {
	$number_items = 1000;
}

?>

<div class="<?php echo esc_attr( trim( $css_class ) ); ?>"
     data-atts="<?php echo esc_attr( json_encode( $atts ) ); ?>">

	<?php if ( ! empty( $username ) ) {
		$media_array    = Lezada_Instagram::scrape_instagram( $username, $number_items, $square_media == 'yes' );
		$instagram_link = 'https://www.instagram.com/' . $username . '/';

		if ( $show_username == 'yes' && $image_align == 'center' ) { ?>
			<div class="user-name"><a
					href="<?php echo esc_url( $instagram_link ); ?>"> <?php echo '@' . esc_html( $username ); ?></a>
			</div>
		<?php } ?>
		<div class="row-instagram row">

			<?php if ( $image_align == 'right' ) { ?>
				<div class="col-lg-4 col-xs-12">
					<?php if ( $show_username == 'yes' ) { ?>
						<div class="user-name"><a
								href="<?php echo esc_url( $instagram_link ); ?>"> <?php echo '@' . esc_html( $username ); ?></a>
						</div>
					<?php }

					if ( $content ) { ?>
						<div class="tm-instagram-follow-links">
							<?php echo esc_attr( $content ); ?>
						</div>
					<?php } ?>
				</div>
			<?php } ?>

			<?php $class_instagram = '';
			if ( $image_align == 'center' ) {
				$class_instagram = 'col-xs-12';
;			} else {
				$class_instagram = 'col-lg-8 col-xs-12';
			}
			?>

			<div class="<?php echo esc_attr($class_instagram); ?>">
				<?php if ( is_wp_error( $media_array ) ) { ?>
					<div class="tm-instagram--error"><p><?php echo esc_attr( $media_array->get_error_message() ); ?></p>
					</div>
				<?php } else { ?>
					<div class="tm-instagram-pics row" style="margin:0 <?php echo( $gap / 2 * - 1 ); ?>px">
						<?php foreach ( $media_array as $item ) { ?>
							<div class="item<?php echo ' ' . $class; ?>"
							     style="padding: 0 <?php echo esc_attr( $gap / 2 ); ?>px <?php echo esc_attr( $gap ); ?>px <?php echo esc_attr( $gap / 2 ); ?>px;">
								<?php if ( $show_likes_comments == 'yes' ) { ?>
									<div class="item-info"
									     style="width:calc(100% - <?php echo esc_attr( $gap ) . 'px'; ?>);left:<?php echo esc_attr( $gap / 2 ) . 'px'; ?>">
										<div class="likes">
											<a href="<?php echo esc_url( $item['link'] ) ?>"
											   target="<?php echo esc_attr( ( $link_new_page == 'yes' ) ? '_blank' : '_self' ); ?>"
											   title="<?php $item['description']; ?>"><span><?php echo esc_attr( $item['likes'] ); ?></span>
											</a></div>
										<div class="comments">
											<a href="<?php echo esc_url( $item['link'] ) ?>"
											   target="<?php echo esc_attr( ( $link_new_page == 'yes' ) ? '_blank' : '_self' ); ?>"
											   title="<?php $item['description']; ?>"><span><?php echo esc_attr( $item['comments'] ); ?></span>
											</a></div>
									</div>
								<?php } ?>

								<img src="<?php echo esc_url( $item['thumbnail'] ); ?>" alt="" class="item-image"/>
								<?php if ( 'video' == $item['type'] ) { ?>
									<span class="play-button"><?php esc_html_e( 'Play', 'lezada-addons' ) ?></span>
								<?php } ?>

								<div class="overlay">
									<a href="<?php echo esc_url( $item['link'] ) ?>"
									   target="<?php echo esc_attr( ( $link_new_page == 'yes' ) ? '_blank' : '_self' ); ?>">
										See on Instagram</a>
								</div>

							</div>
						<?php } ?>
					</div>
				<?php } ?>
			</div>

			<?php if ( $image_align == 'left' ) { ?>
				<div class="col-lg-4 col-xs-12">
					<?php if ( $show_username == 'yes' ) { ?>
						<div class="user-name"><a
								href="<?php echo esc_url( $instagram_link ); ?>"> <?php echo '@' . esc_html( $username ); ?></a>
						</div>
					<?php }

					if ( $content ) { ?>
						<div class="tm-instagram-follow-links">
							<?php echo esc_attr( $content ); ?>
						</div>
					<?php } ?>
				</div>
			<?php } ?>
		</div>
	<?php } ?>
</div>
