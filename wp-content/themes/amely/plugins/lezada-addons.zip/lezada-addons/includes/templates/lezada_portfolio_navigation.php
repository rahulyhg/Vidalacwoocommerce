<?php
/**
 * Shortcode attributes
 *
 * @var $atts
 * @var $animation
 * @var $custom_archive
 * @var $same_category
 * @var $custom_archive_link
 * @var $el_class
 * @var $css
 * @var $css_id
 * @var $animation
 * Shortcode class
 * @var $this WPBakeryShortCode_Lezada_Button
 */

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$el_class  = $this->getExtraClass( $el_class );

$animation_classes = $this->getCSSAnimation( $animation );

$css_class = array(
	'tm-shortcode',
	'lezada-portfolio-navigation',
	'button',
	$animation_classes,
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);

$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
	implode( ' ', $css_class ),
	$this->settings['base'],
	$atts );

if ( $animation !== '' ) {
	$css_class .= ' tm-animation ' . $animation . '';
}

//parse link
if ( $custom_archive ) {
	// Get archive link
	$link         = vc_build_link( $custom_archive_link );
	$archive_link = ( isset( $link['url'] ) && ( $link['url'] != '' ) ) ? $link['url'] : '#';
} else {
	$archive_link = get_post_type_archive_link( 'ic_portfolio' );
}

?>

<div class="<?php echo esc_attr( trim( $css_class ) ); ?>">
	<div class="insight-portfolio-navigation">
		<div class="row row-xs-center">
			<div class="col-md-4 col-left">
				<?php previous_post_link( '%link', '<i class="ti-angle-left"></i> Previous' ); ?>
			</div>
			<div class="col-md-4 col-center">
				<a href="<?php echo esc_url( $archive_link ); ?>">
					<img src="<?php echo esc_url(LEZADA_CHILD_THEME_URI . '/assets/images/nav.svg'); ?>"
					     alt="<?php esc_html_e( 'Portfolio', 'tm-wilson' ); ?>"/>
				</a>
			</div>
			<div class="col-md-4 col-right">
				<?php
				next_post_link( '%link', 'Next <i class="ti-angle-right"></i>' );
				?>
			</div>
		</div>
	</div>
</div>

